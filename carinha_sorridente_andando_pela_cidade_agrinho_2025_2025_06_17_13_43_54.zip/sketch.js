function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
/*

Rosto pixel art com olhos pretos que seguem o mouse, sem borda branca ao redor,

fundo estilizado de cidade atrás do rosto.

*/

// Função setup - configura o canvas

function setup() {

  createCanvas(400, 400);

}

// Função draw - desenha a cena toda a cada frame

function draw() {

  background(180, 200, 220); // Fundo azul suave para céu

  // Desenha o fundo da cidade simplificado

  drawCityBackground();

  // Cabeça do rosto

  fill(250, 224, 189); // Tom de pele

  stroke(110, 70, 40); // Contorno sutil

  strokeWeight(3);

  ellipse(width / 2, height / 2, 260, 300);

  // Bochechas levemente rosadas transparentes

  noStroke();

  fill(255, 150, 180, 120);

  ellipse(width / 2 - 70, height / 2 + 40, 50, 30);

  ellipse(width / 2 + 70, height / 2 + 40, 50, 30);

  // Sobrancelhas arqueadas

  stroke(110, 70, 40);

  strokeWeight(4);

  noFill();

  const browOffset = QUARTER_PI / 1.5;

  arc(width / 2 - 60, height / 2 - 75, 70, 30, PI + browOffset, TWO_PI - browOffset);

  arc(width / 2 + 60, height / 2 - 75, 70, 30, PI + browOffset, TWO_PI - browOffset);

  // Nariz simples

  noStroke();

  fill(250, 210, 170);

  ellipse(width / 2, height / 2 + 30, 18, 12);

  // Boca sorridente

  stroke(200, 50, 50);

  strokeWeight(3);

  noFill();

  arc(width / 2, height / 2 + 90, 90, 50, 0, PI);

  // Olhos pretos com brilho branco e sem borda branca ao redor

  const eyeXLeft = width / 2 - 60;

  const eyeXRight = width / 2 + 60;

  const eyeY = height / 2 - 30;

  const pupilMaxOffset = 22;

  // Calcula ângulo para pupilas posicionarem juntas e sincronizadas

  let dx = mouseX - width / 2;

  let dy = mouseY - eyeY;

  let angle = atan2(dy, dx);

  let distToMouse = dist(mouseX, mouseY, width / 2, eyeY);

  let distance = min(pupilMaxOffset, distToMouse);

  let offsetX = cos(angle) * distance;

  let offsetY = sin(angle) * distance;

  fill(0);

  noStroke();

  ellipse(eyeXLeft + offsetX, eyeY + offsetY, 35, 43);

  ellipse(eyeXRight + offsetX, eyeY + offsetY, 35, 43);

  // Reflexos das pupilas (brilho)

  fill(255, 230);

  ellipse(eyeXLeft + offsetX - 10, eyeY + offsetY - 10, 12, 16);

  ellipse(eyeXRight + offsetX - 10, eyeY + offsetY - 10, 12, 16);

}

// Função para desenhar fundo simplificado estilo cidade

function drawCityBackground() {

  noStroke();

  // Prédios estilizados simples e em perspectiva

  const baseY = height * 0.85;

  const buildingColors = ['#a0a4a8', '#8a8e93', '#b0b4b8', '#6e7275'];

  for(let i = -50; i < width + 50; i += 60) {

    const w = random(30, 50);

    const h = random(80, 150);

    fill(random(buildingColors));

    rect(i, baseY - h, w, h, 6);

    // Janela simples em grid

    fill('#e3e6eb');

    for(let y = baseY - h + 10; y < baseY - 10; y += 25) {

      for(let x = i + 6; x < i + w - 10; x += 18) {

        rect(x, y, 12, 18, 2);

      }

    }

  }

  // Rua simples (base escura)

  fill('#45494d');

  rect(0, baseY, width, height - baseY);

}